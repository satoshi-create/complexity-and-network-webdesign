import boto3
import json

textract = boto3.client('textract')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        print(f"Processing file: {key}")

        response = textract.analyze_document(
            Document={'S3Object': {'Bucket': bucket, 'Name': key}},
            FeatureTypes=['FORMS']
        )

        # 抽出結果をJSONでS3に保存
        result_key = key.replace('.jpg', '_extracted.json')
        s3.put_object(
            Bucket=bucket,
            Key=result_key,
            Body=json.dumps(response, ensure_ascii=False)
        )

        print(f"OCR result saved to: {result_key}")
